// Import necessary modules and textures
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import starsTexture from './src/img/stars.jpg';
import sunTexture from './src/img/sun.jpg';
import mercuryTexture from './src/img/mercury.jpg';
import venusTexture from './src/img/venus.jpg';
import earthTexture from './src/img/earth.jpg';
import marsTexture from './src/img/mars.jpg';
import jupiterTexture from './src/img/jupiter.jpg';
import saturnTexture from './src/img/saturn.jpg';
import saturnRingTexture from './src/img/saturn ring.png';
import uranusTexture from './src/img/uranus.jpg';
import uranusRingTexture from './src/img/uranus ring.png';
import neptuneTexture from './src/img/neptune.jpg';
import plutoTexture from './src/img/pluto.jpg';

// Setup the API URL with your API key
const apiUrl = 'https://api.nasa.gov/neo/rest/v1/feed?start_date=2015-09-07&end_date=2015-09-08&detailed=false&api_key=5hKvIYlcpTxBk8EWxEDJA8gH9dRFAeI8hqpLsodz'; // Replace with your API key

// Initialize global variables
const celestialBodies = [];
const mouse = new THREE.Vector2();
const raycaster = new THREE.Raycaster();

// Create the renderer
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Create the scene
const scene = new THREE.Scene();

// Create the camera
const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(-90, 140, 140);

// Setup the background
const cubeTextureLoader = new THREE.CubeTextureLoader();
scene.background = cubeTextureLoader.load([starsTexture, starsTexture, starsTexture, starsTexture, starsTexture, starsTexture]);

// Setup orbit controls
const orbit = new OrbitControls(camera, renderer.domElement);
orbit.update();

// Setup lights
const ambientLight = new THREE.AmbientLight(0xffffff);
scene.add(ambientLight);
const pointLight = new THREE.PointLight(0xffffff, 3, 100);
scene.add(pointLight);

// Load textures
const textureLoader = new THREE.TextureLoader();

// Create the sun
const sunGeo = new THREE.SphereGeometry(12, 25, 20);
const sunMat = new THREE.MeshBasicMaterial({ map: textureLoader.load(sunTexture) });
const sun = new THREE.Mesh(sunGeo, sunMat);
scene.add(sun);

// Function to create planets
function createPlanet(size, texture, position, ring) {
  const geometry = new THREE.SphereGeometry(size, 25, 20);
  const material = new THREE.MeshStandardMaterial({ map: textureLoader.load(texture) });
  const planet = new THREE.Mesh(geometry, material);
  const planetObj = new THREE.Object3D();
  planetObj.add(planet);
  scene.add(planetObj);
  planet.position.x = position;

  // Check if `ring` is defined
  if (ring) {
    const ringGeo = new THREE.RingGeometry(ring.innerRadius, ring.outerRadius, 30);
    const ringMat = new THREE.MeshStandardMaterial({ 
      map: textureLoader.load(ring.texture), 
      side: THREE.DoubleSide 
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    planetObj.add(ringMesh);

    ringMesh.position.x = position;
    ringMesh.rotation.x = -0.5 * Math.PI;
  }

  return { planet, planetObj };
}

// Load planets
const mercury = createPlanet(4, mercuryTexture, 20);
const venus = createPlanet(5, venusTexture, 40);
const earth = createPlanet(5.56, earthTexture, 60);
const mars = createPlanet(5, marsTexture, 80);
const jupiter = createPlanet(6, jupiterTexture, 100);
const saturn = createPlanet(8, saturnTexture, 150, { 
  innerRadius: 10, 
  outerRadius: 20, 
  texture: saturnRingTexture 
});
const uranus = createPlanet(8.2, uranusTexture, 200, { 
  innerRadius: 10, 
  outerRadius: 20, 
  texture: uranusRingTexture 
});
const neptune = createPlanet(5, neptuneTexture, 240);

// Fetch NEO data and add to the scene
async function fetchNeoData() {
  try {
    const response = await fetch(apiUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const data = await response.json();
    console.log('API response:', data);

    const dateKey = '2015-09-07';  // Adjust to your date
    if (data.near_earth_objects && data.near_earth_objects[dateKey]) {
      const neosData = data.near_earth_objects[dateKey];
      if (Array.isArray(neosData)) {
        neosData.forEach((neo, index) => {
          const size = (neo.estimated_diameter.kilometers.estimated_diameter_min +
              neo.estimated_diameter.kilometers.estimated_diameter_max) / 2 * 20;
          const geometry = new THREE.SphereGeometry(size, 18, 10);
          const material = new THREE.MeshBasicMaterial({ color: 0xff0000 });
          const neoSphere = new THREE.Mesh(geometry, material);
          const distance = Math.random() * 30 + 10;
          neoSphere.position.x = Math.cos(index) * distance;
          neoSphere.position.y = Math.sin(index) * distance;
          neoSphere.position.z = (Math.random() - 0.5) * 50;

          neoSphere.neoData = {
            name: neo.name,
            approachDate: neo.close_approach_data && neo.close_approach_data[0] ? neo.close_approach_data[0].close_approach_date : 'Unknown'
          };

          celestialBodies.push(neoSphere);
          scene.add(neoSphere);
        });
      } else {
        console.error('NEO data is not an array:', neosData);
      }
    } else {
      console.error('No NEO data found for the specified date:', data.near_earth_objects);
    }
  } catch (error) {
    console.error('Error fetching NEO data:', error);
  }
}

// Handle mouse movement
function onMouseMove(event) {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);

  const intersects = raycaster.intersectObjects(celestialBodies);

  if (intersects.length > 0) {
    const intersectedObject = intersects[0].object;
    const neoInfo = document.getElementById('neo-info');
    neoInfo.style.display = 'block';
    neoInfo.style.left = `${event.clientX + 10}px`;
    neoInfo.style.top = `${event.clientY + 10}px`;
    neoInfo.innerHTML = `NEO: ${intersectedObject.neoData.name}<br>Date: ${intersectedObject.neoData.approachDate}`;
  } else {
    document.getElementById('neo-info').style.display = 'none';
  }
}

// Animate the scene
function animate() {
  sun.rotateY(0.002);
  mercury.planet.rotateY(0.001);
  mercury.planetObj.rotateY(0.001);
  venus.planet.rotateY(0.0012);
  venus.planetObj.rotateY(0.0015);
  earth.planet.rotateY(0.012);
  earth.planetObj.rotateY(0.0012);
  mars.planet.rotateY(0.013);
  mars.planetObj.rotateY(0.0019);
  jupiter.planet.rotateY(0.04);
  jupiter.planetObj.rotateY(0.0023);
  saturn.planet.rotateY(0.01);
  saturn.planetObj.rotateY(0.0021);
  uranus.planet.rotateY(0.01);
  uranus.planetObj.rotateY(0.0015);
  neptune.planet.rotateY(0.01);
  neptune.planetObj.rotateY(0.001);

  renderer.render(scene, camera);
}

// Set up the animation loop
renderer.setAnimationLoop(animate);

// Handle window resize
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

window.addEventListener('resize', onWindowResize);
window.addEventListener('mousemove', onMouseMove);

// Fetch NEO data
fetchNeoData();
