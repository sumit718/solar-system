// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    fetch('conti.json')
        .then(response => response.json())
        .then(data => {
            const contributorsContainer = document.getElementById('contributors');
            
            data.forEach(contributor => {
                const contributorDiv = document.createElement('div');
                contributorDiv.className = 'p-4 rounded-lg shadow-md text-center con';
                
                contributorDiv.innerHTML = `
                    <img src="${contributor.image}" alt="Contributor" class="w-32 h-32 rounded-full mx-auto mb-4">
                    <h3 class="font-bold">${contributor.name}</h3>
                    <a href="${contributor.linkedin}" class="contact-link" target="_blank" title="LinkedIn">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <a href="${contributor.github}" class="contact-link" target="_blank" title="GitHub">
                        <i class="fab fa-github"></i>
                    </a>
                    <a href="mailto:${contributor.email}" class="contact-link" title="Email">
                        <i class="fas fa-envelope"></i>
                    </a>
                    <a href="tel:${contributor.phone}" class="contact-link" title="Phone">
                        <i class="fas fa-phone"></i>
                    </a>
                    <p class="text-gray-600">${contributor.desc}</p>
                `;
                
                contributorsContainer.appendChild(contributorDiv);
            });
        })
        .catch(error => console.error('Error fetching JSON:', error));
});
