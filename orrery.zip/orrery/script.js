
// Fetch NEO data from NASA API
// async function fetchNeoData() {
//     const apiUrl = 'http://api.nasa.gov/neo/rest/v1/feed?start_date=2015-09-07&end_date=2015-09-08&detailed=false&api_key=5hKvIYlcpTxBk8EWxEDJA8gH9dRFAeI8hqpLsodz';
    
//     try {
//         const response = await fetch(apiUrl);
//         const data = await response.json();
//         return data.near_earth_objects['2015-09-08'];
//     } catch (error) {
//         console.error('Error fetching NEO data:', error);
//     }
// }

// // Display NEO data on the page
// async function displayNeoData() {
//     const neos = await fetchNeoData();
//     const neoContainer = document.getElementById('neo-container');

//     if (!neos) {
//         neoContainer.innerHTML = "<p>No data available.</p>";
//         return;
//     }

//     neos.forEach(neo => {
//         const neoCard = document.createElement('div');
//         neoCard.className = 'card mb-3';
//         neoCard.innerHTML = `
//             <div class="card-body">
//                 <h5 class="card-title">${neo.name}</h5>
//                 <p class="card-text">ID: ${neo.neo_reference_id}</p>
//                 <p class="card-text">Magnitude: ${neo.absolute_magnitude_h}</p>
//                 <p class="card-text">Diameter (min): ${neo.estimated_diameter.kilometers.estimated_diameter_min.toFixed(2)} km</p>
//                 <p class="card-text">Diameter (max): ${neo.estimated_diameter.kilometers.estimated_diameter_max.toFixed(2)} km</p>
//                 <p class="card-text">Potentially Hazardous: ${neo.is_potentially_hazardous_asteroid ? 'Yes' : 'No'}</p>
//                 <p class="card-text">Close Approach Date: ${neo.close_approach_data[0].close_approach_date_full}</p>
//                 <p class="card-text">Relative Velocity: ${neo.close_approach_data[0].relative_velocity.kilometers_per_hour} km/h</p>
//                 <p class="card-text">Miss Distance: ${neo.close_approach_data[0].miss_distance.kilometers} km</p>
//                 <p class="card-text">Orbiting Body: ${neo.close_approach_data[0].orbiting_body}</p>
//                 <a href="${neo.nasa_jpl_url}" target="_blank" class="btn btn-primary">More Info</a>
//             </div>
//         `;
//         neoContainer.appendChild(neoCard);
//     });
// }

// // Initialize NEO display when page loads
// document.addEventListener('DOMContentLoaded', displayNeoData);
// Set API key and base URL
const apiKey = '5hKvIYlcpTxBk8EWxEDJA8gH9dRFAeI8hqpLsodz';
const baseUrl = 'http://api.nasa.gov/neo/rest/v1/feed';

// Set initial date range
let startDate = '2015-09-07';
let endDate = '2015-09-08';

// Fetch NEO data from NASA API
async function fetchNeoData(startDate, endDate) {
    const apiUrl = `${baseUrl}?start_date=${startDate}&end_date=${endDate}&detailed=false&api_key=${apiKey}`;
    
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        return data.near_earth_objects;
    } catch (error) {
        console.error('Error fetching NEO data:', error);
    }
}

// Display NEO data on the page
async function displayNeoData(neos, date) {
    const neoContainer = document.getElementById('neo-container');

    if (!neos) {
        neoContainer.innerHTML = "<p>No data available.</p>";
        return;
    }

    neoContainer.innerHTML = ''; // Clear existing content

    neos.forEach(neo => {
        const neoCard = document.createElement('div');
        neoCard.className = 'card mb-3';
        neoCard.innerHTML = `
            <div class="card-body">
                <h5 class="card-title">${neo.name}</h5>
                <p class="card-text">ID: ${neo.neo_reference_id}</p>
                <p class="card-text">Magnitude: ${neo.absolute_magnitude_h}</p>
                <p class="card-text">Diameter (min): ${neo.estimated_diameter.kilometers.estimated_diameter_min.toFixed(2)} km</p>
                <p class="card-text">Diameter (max): ${neo.estimated_diameter.kilometers.estimated_diameter_max.toFixed(2)} km</p>
                <p class="card-text">Potentially Hazardous: ${neo.is_potentially_hazardous_asteroid ? 'Yes' : 'No'}</p>
                <p class="card-text">Close Approach Date: ${neo.close_approach_data[0].close_approach_date_full}</p>
                <p class="card-text">Relative Velocity: ${neo.close_approach_data[0].relative_velocity.kilometers_per_hour} km/h</p>
                <p class="card-text">Miss Distance: ${neo.close_approach_data[0].miss_distance.kilometers} km</p>
                <p class="card-text">Orbiting Body: ${neo.close_approach_data[0].orbiting_body}</p>
                <a href="${neo.nasa_jpl_url}" target="_blank" class="btn btn-primary">More Info</a>
            </div>
        `;
        neoContainer.appendChild(neoCard);
    });
}

// Initialize NEO display when page loads
document.addEventListener('DOMContentLoaded', async () => {
    const neos = await fetchNeoData(startDate, endDate);
    displayNeoData(neos[endDate], endDate);

    // Add previous and next buttons
    const buttonContainer = document.getElementById('button-container');
    const prevButton = document.createElement('button');
    prevButton.className = 'btn btn-secondary';
    prevButton.textContent = 'Previous';
    prevButton.onclick = async () => {
        const date = new Date(startDate);
        date.setDate(date.getDate() - 1);
        startDate = date.toISOString().split('T')[0];
        endDate = new Date(startDate).setDate(date.getDate() + 1);
        endDate = new Date(endDate).toISOString().split('T')[0];
        const neos = await fetchNeoData(startDate, endDate);
        displayNeoData(neos[endDate], endDate);
    };
    buttonContainer.appendChild(prevButton);

    const nextButton = document.createElement('button');
    nextButton.className = 'btn btn-secondary';
    nextButton.textContent = 'Next';
    nextButton.onclick = async () => {
        const date = new Date(endDate);
        date.setDate(date.getDate() + 1);
        startDate = new Date(date).setDate(date.getDate() - 1);
        startDate = new Date(startDate).toISOString().split('T')[0];
        endDate = date.toISOString().split('T')[0];
        const neos = await fetchNeoData(startDate, endDate);
        displayNeoData(neos[endDate], endDate);
    };
    buttonContainer.appendChild(nextButton);
});
